import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  get ats => TextStyle();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff415093),
      appBar: AppBar(
        backgroundColor: Color(
          0xff415093,
        ),
        title: Text(
          "chat Together",
          style: ats,
        ),
      ),
      body: GridView.builder(
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
        ),
        itemCount: 5,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: ListTile(
              tileColor: Colors.red,
            ),
          );
        },
      ),
    );
  }
}
